l'app costruita da me � inserita nelle due cartelle: public e app.
tutto il resto � generato automaticamente dalle istallazioni di Composer per il framework Slim 3
