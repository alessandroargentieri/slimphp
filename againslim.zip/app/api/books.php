<?php

//GET HI CALL
//call: http://localhost/againslim/public/index.php/api/books/hi
$app->get('/api/books/hi',function(){ echo "Welcome to books!";});


//GET ALL BOOKS LIST FROM DB
//call: http://localhost/againslim/public/index.php/api/books
$app->get('/api/books',function(){ 
	require_once('dbconnect.php');
	
	$query = "select * from books";
	$result = $mysqli->query($query);    //$mysqli was defined into dbconnect.php
	
	while($row = $result->fetch_assoc()){
		$data[] = $row;
	}
	if(isset($data)){  //if there is data available from the query result
		header('Content-Type: application/json');  //good practice
		echo json_encode($data);
	}else{
		echo "Sorry! No data is available!";
	}
});


//GET BOOK INFO FROM DB USING ID
//call: http://localhost/againslim/public/index.php/api/books/1
$app->get('/api/books/{id}',function($request){ 
	require_once('dbconnect.php');
	$id = $request->getAttribute('id');
	
	$query = "select * from books where id=$id"; //le doppie virgole permettono di usare le variabili all'interno
	$result = $mysqli->query($query);    //$mysqli was defined into dbconnect.php
	
	$data[] = $result->fetch_assoc();
	header('Content-Type: application/json');  //good practice
	echo json_encode($data);
});


//POST AND VIEW BOOK INFO EXAMPLE
//post book info to : http://localhost/againslim/public/index.php/api/books/view_a_book
$app->post('/api/books/view_a_book', function ($request) {
    foreach($_POST as $key =>$value){
		echo "<b>$key</b> was posted with a value of <b>$value</b> </br>";
	}
});

//POST A BOOK INFO AND SAVE IN DB
//post info BOOK on: http://localhost/againslim/public/index.php/api/books/insert
$app->post('/api/books/insert',function($request){ 

	$title = $request->getParsedBody()['book_title']; 
	$author = $request->getParsedBody()['author']; 
	$amazon_url = $request->getParsedBody()['amazon_url'];
	
	require_once('dbconnect.php');
	
	$query = "insert into books (book_title,author,amazon_url) values('".$title."','".$author."','".$amazon_url."');"; //le doppie virgole permettono di usare le variabili all'interno
	$result = $mysqli->query($query);    //$mysqli was defined into dbconnect.php
	if($result === true){
		echo 'Inserimento avvenuto con successo!';
	}else{
		echo 'Inserimento non avvenuto!';
	}
	
});

//POST A BOOK INFO THROUGH JSON AND SAVE IN DB
//post info BOOK on: http://localhost/againslim/public/index.php/api/books/insertJson
$app->post('/api/books/insertJson',function($request){ 

	//foreach($_POST as $key =>$value){
	//	echo "<b>$key</b> was posted with a value of <b>$value</b> </br>";
	//}
	
	$json = $_POST;
	
	$title = $json['book_title'];
	$author = $json['author'];
	$amazon_url = $json['amazon_url'];
	
	echo "Book title: ". $json['book_title'] ."</br>";
	echo "Author: ". $json['author'] ."</br>";
	echo "Amazon URL: ". $json['amazon_url'] ."</br>";
	
	require_once('dbconnect.php');
	
	$query = "insert into books (book_title,author,amazon_url) values('".$title."','".$author."','".$amazon_url."');"; //le doppie virgole permettono di usare le variabili all'interno
	$result = $mysqli->query($query);    //$mysqli was defined into dbconnect.php
	if($result === true){
		echo 'Inserimento avvenuto con successo!';
	}else{
		echo 'Inserimento non avvenuto!';
	}
	
});


//POST A BOOK INFO THROUGH JSONSTRING AND SAVE IN DB
//post info BOOK on: http://localhost/againslim/public/index.php/api/books/insertJsonString
$app->post('/api/books/insertJsonString',function($request){ 

	//foreach($_POST as $key =>$value){
	//	echo "<b>$key</b> was posted with a value of <b>$value</b> </br>";
	//}
	
	$jsonString = $_POST;
	$json = json_decode($jsonString,true);
	
	$title = $json['book_title'];
	$author = $json['author'];
	$amazon_url = $json['amazon_url'];
	
	echo "Book title: ". $json['book_title'] ."</br>";
	echo "Author: ". $json['author'] ."</br>";
	echo "Amazon URL: ". $json['amazon_url'] ."</br>";
	
	require_once('dbconnect.php');
	
	$query = "insert into books (book_title,author,amazon_url) values('".$title."','".$author."','".$amazon_url."');"; //le doppie virgole permettono di usare le variabili all'interno
	$result = $mysqli->query($query);    //$mysqli was defined into dbconnect.php
	if($result === true){
		echo 'Inserimento avvenuto con successo!';
	}else{
		echo 'Inserimento non avvenuto!';
	}
	
});




?>