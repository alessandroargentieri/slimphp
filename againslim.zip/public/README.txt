in index.php sono richiamati pezzi di codice del folder app/api/books.php e app/api/dbconnect.php
In essi vengono istanziate e inizializzate variabili relative alla connessione e all'app Slim.

Quindi non vedremo nessuna inizializzazione o passaggio di parametri, perch� nel PHP basta includere un pezzo di
codice per non dover passare parametri o istanziare in locale una variabile.

json_decode traduce una stringa in un array json
json_encode traduce un array in una stringa in formato json.

PS: i percorsi degli URL per accedere al WS restfull non centrano niente con i subfolder in cui troviamo i pezzi di 
codice importati in index.php.
Ovvero si scrive correttamente l'URL fino ad index.php (http://localhost/againslim/public/index.php) e poi segue
l'URL logico inserito nelle specifiche dell'app ed indipendente dai subfolder eventuali in cui abbiamo stanziato
le porzioni di codice che effettuano una particolare funzione seguendo il paradigma restful.