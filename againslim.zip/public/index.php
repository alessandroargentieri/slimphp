<?php
//use \Psr\Http\Message\ServerRequestInterface as Request;
//use \Psr\Http\Message\ResponseInterface as Response;

//require 'vendor/autoload.php';  //versione originale in cui index.php non è in una sottocartella
require '../vendor/autoload.php'; //versione corretta x mettere le nostre pagine in 'public'

$app = new \Slim\App();

//da dichiarare per forza dopo l'istanziazione di $app xke la utilizza senza dichiararla: si richiama con il seguente URL: localhost/againslim/public/index.php/api/books
require_once ('../app/api/books.php');

$app->get('/', function ($request, $response) {
    $response->getBody()->write("Ciao questo è Slim!");
    return $response;
});

////////////////////////GET NAME/////////////////////////////////////////
//PRIMO METODO
$app->get('/hi/{name}', function ($request, $response, $args) {
    $name = $args['name'];
    $response->getBody()->write("Hi, $name");
    return $response;
});
//SECONDO METODO
$app->get('/hello/{name}', function ($request, $response) {
    $name = $request->getAttribute('name');
    $response->getBody()->write("Hello, $name");
    return $response;
});

////////////////////POST NAME////////////////////////////////////////////

//POST NAME EXAMPLE
//post my_name = "Alessandro" to : http://localhost/againslim/public/index.php/hello
$app->post('/hello', function ($request) {
    $my_name = $_POST['my_name'];
	echo "hello ".$my_name;
});

//POST NAME EXAMPLE 2
//post my_name = "Alessandro" to : http://localhost/againslim/public/index.php/hi
$app->post('/hi', function ($request) {
    //$my_name = $_POST['my_name'];
	$my_name = $request->getParsedBody()['my_name']; //works with all requests (GET/PUT/POST/DELETE)
	echo "hi ".$my_name;
});



$app->get('/somma', function ($request, $response) {
    $response->getBody()->write("La sintassi corretta è: /somma/NUM1/NUM2");
    return $response;
});

$app->get('/somma/{number1}/{number2}', function ($request, $response) {
    $num1 = $request->getAttribute('number1');
	$num2 = $request->getAttribute('number2');
    $response->getBody()->write("Somma: ".($num1 + $num2));
    return $response;
});

$app->run();


?>